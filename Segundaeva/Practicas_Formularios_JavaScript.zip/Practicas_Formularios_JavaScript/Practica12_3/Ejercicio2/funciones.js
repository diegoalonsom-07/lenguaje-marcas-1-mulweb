function enfocar(elemento) {
    elemento.style.background = "yellow";
}

function desenfocar(elemento) {
    elemento.style.background = "white";
}