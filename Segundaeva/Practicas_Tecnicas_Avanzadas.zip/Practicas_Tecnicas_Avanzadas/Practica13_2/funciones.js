function resaltado(id_objeto) {
    document.getElementById(id_objeto).style.height = "300px";
    document.getElementById(id_objeto).style.width = "400px";
    document.getElementById(id_objeto).style.opacity = "100%";
}
function normal(id_objeto) {
    document.getElementById(id_objeto).style.height = "150px";
    document.getElementById(id_objeto).style.width = "200px";
    document.getElementById(id_objeto).style.opacity = "50%";
}
